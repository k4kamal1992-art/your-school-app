# Your School App — Screen Map

## Phase 1 — App Foundation (10)
1. P1Splash — Splash Screen
2. P1On1 — Onboarding 1
3. P1On2 — Onboarding 2
4. P1On3 — Onboarding 3
5. P1Login — Login
6. P1OTP — OTP Verification
7. P1Reset — Reset Password
8. P1Language — Language Selection
9. P1Terms — Terms & Conditions
10. P1HomeIntro — App Introduction / Welcome

## Phase 2 — School Registration + Login (8)
11. P2Create — Create Your School
12. P2IdCheck — School ID Availability Check
13. P2Success — School Created Successfully
14. P2Admin — First Admin Setup
15. P2Join — Join Existing School
16. P2Login — School Login
17. P2Verify — School / Role Verification
18. P2Welcome — Welcome / Dashboard Routing

## Phase 3 — School Admin Module (10)
19. P3Dashboard — Admin Dashboard
20. P3Teachers — Teacher Management
21. P3Students — Student Management
22. P3Parents — Parent / Guardian Management
23. P3Classes — Class & Section Management
24. P3Subjects — Subject Management
25. P3Routine — Routine Management
26. P3Attendance — Attendance Overview
27. P3Exams — Exam & Result Management
28. P3Notices — Notice & School Settings

### Phase 3 design rule
Phase 3 keeps the same Phase 1/2 visual system: blue + white + subtle pastel accents, rounded cards, large touch targets, simple iconography and clean education-focused layout. It adds only module-specific UI and interaction polish; it does not redesign the approved visual identity.

### Important prototype note
This project is a UI/navigation prototype. Real backend APIs, PostgreSQL/Prisma persistence, OTP delivery, role-based authorization, tenant isolation enforcement and production authentication are not implemented in this ZIP.
