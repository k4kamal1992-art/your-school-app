# GitHub APK Setup

Keep `your-school-app.zip` in the repository root.

Add `.github/workflows/build-apk-from-zip.yml` to the repository.

Create an Expo access token and save it in:
GitHub → Settings → Secrets and variables → Actions → New repository secret

Name: EXPO_TOKEN

Then:
GitHub → Actions → Build Android APK from ZIP → Run workflow → Run workflow.

The action extracts the ZIP and submits the Expo EAS Android preview build.
