// ============================================================
// Supabase configuration — Milestone 1
// ============================================================
window.SUPABASE_URL = "https://zcyxitdufnaghfgnjfkb.supabase.co";
window.SUPABASE_ANON_KEY = "sb_publishable_3ymsHFhr_2cDc-c30soJlA_KOlhxZIN";
