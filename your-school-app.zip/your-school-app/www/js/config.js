// ============================================================
// Supabase configuration — Milestone 1
// ============================================================
window.SUPABASE_URL = "https://zcyxitdufnaghfgnjfkb.supabase.co";
window.SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InpjeXhpdGR1Zm5hZ2hmZ25qZmtiIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODkzOTkzMDIsImV4cCI6MjEwNDk3NTMwMn0.4-tAlMXCbJWu01czqCW8C9qwS8Rf5WG9DnBAoFPEGvA";
