// ============================================================
// Supabase configuration — Milestone 1
// ============================================================
// Supabase project তৈরি করার পর:
//   Project Settings -> API  -> এখানে "Project URL" ও "anon public" key পাবেন
// নিচের দুটো লাইনে সেই মান বসান, তারপর zip আবার বানিয়ে GitHub-এ push করুন।
//
// যতক্ষণ এখানে "YOUR_SUPABASE_URL_HERE" থেকে যাবে, ততক্ষণ Phase 2/3-এর
// screen-গুলো আগের মতোই শুধু ডিজাইন-মকআপ হিসেবে কাজ করবে (কোনো ভুল হবে না,
// শুধু real data connect হবে না)।
// ============================================================

window.SUPABASE_URL = "YOUR_SUPABASE_URL_HERE";
window.SUPABASE_ANON_KEY = "YOUR_SUPABASE_ANON_KEY_HERE";
