-- =====================================================================
-- Your School App — Database Schema (Milestone 1)
-- Run this once in Supabase: Dashboard -> SQL Editor -> New query -> Run
-- =====================================================================

-- 1. SCHOOLS ---------------------------------------------------------
create table schools (
  id uuid primary key default gen_random_uuid(),
  school_id text unique not null,          -- e.g. ABCHS001, chosen by the school itself
  name text not null,
  type text,                                -- Government / Private / Madrasa etc.
  address text,
  district text,
  state text,
  admin_mobile text,
  created_at timestamptz default now()
);

-- 2. PROFILES ---------------------------------------------------------
-- One row per app user (admin / teacher / student / parent), linked to Supabase Auth.
create table profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  school_id uuid references schools(id) on delete cascade,
  role text not null check (role in ('admin','teacher','student','parent')),
  full_name text not null,
  mobile text,
  designation text,                         -- for admin/teacher, e.g. "Headmaster"
  created_at timestamptz default now()
);

-- 3. CLASSES ------------------------------------------------------------
create table classes (
  id uuid primary key default gen_random_uuid(),
  school_id uuid references schools(id) on delete cascade,
  name text not null,                       -- e.g. "Class 8"
  section text not null,                    -- e.g. "B"
  class_teacher_id uuid references profiles(id),
  created_at timestamptz default now()
);

-- 4. STUDENT DETAILS (extends a profile with role='student') -----------
create table student_details (
  profile_id uuid primary key references profiles(id) on delete cascade,
  school_id uuid references schools(id) on delete cascade,
  class_id uuid references classes(id),
  roll text,
  guardian_id uuid references profiles(id)   -- links to a parent profile
);

-- 5. NOTICES ------------------------------------------------------------
create table notices (
  id uuid primary key default gen_random_uuid(),
  school_id uuid references schools(id) on delete cascade,
  title text not null,
  body text,
  target_role text default 'all',            -- all / teacher / student / parent
  created_by uuid references profiles(id),
  created_at timestamptz default now()
);

-- 6. ATTENDANCE ----------------------------------------------------------
create table attendance (
  id uuid primary key default gen_random_uuid(),
  school_id uuid references schools(id) on delete cascade,
  student_id uuid references profiles(id) on delete cascade,
  class_id uuid references classes(id),
  date date not null,
  status text not null check (status in ('present','absent','late')),
  marked_by uuid references profiles(id),
  created_at timestamptz default now(),
  unique (student_id, date)
);

-- =====================================================================
-- ROW LEVEL SECURITY — this is what stops one school from ever seeing
-- another school's data, enforced by the database itself.
-- =====================================================================

alter table schools enable row level security;
alter table profiles enable row level security;
alter table classes enable row level security;
alter table student_details enable row level security;
alter table notices enable row level security;
alter table attendance enable row level security;

-- Helper: the logged-in user's own school_id
create or replace function my_school_id() returns uuid as $$
  select school_id from profiles where id = auth.uid();
$$ language sql stable security definer;

-- Helper: the logged-in user's own role
create or replace function my_role() returns text as $$
  select role from profiles where id = auth.uid();
$$ language sql stable security definer;

-- schools: a user can only read their own school's row
create policy "read own school" on schools
  for select using (id = my_school_id());

-- profiles: a user can read every profile inside their own school
create policy "read same-school profiles" on profiles
  for select using (school_id = my_school_id());

-- profiles: a user can update only their own row
create policy "update own profile" on profiles
  for update using (id = auth.uid());

-- classes / student_details / notices / attendance:
-- readable by anyone in the same school
create policy "read same-school classes" on classes
  for select using (school_id = my_school_id());

create policy "read same-school students" on student_details
  for select using (school_id = my_school_id());

create policy "read same-school notices" on notices
  for select using (school_id = my_school_id());

create policy "read same-school attendance" on attendance
  for select using (school_id = my_school_id());

-- Only an admin can create classes / notices for their own school
create policy "admin manages classes" on classes
  for insert with check (school_id = my_school_id() and my_role() = 'admin');

create policy "admin manages notices" on notices
  for insert with check (school_id = my_school_id() and my_role() = 'admin');

-- Only a teacher/admin can mark attendance, and only within their own school
create policy "teacher marks attendance" on attendance
  for insert with check (school_id = my_school_id() and my_role() in ('teacher','admin'));
