# Your School App — Claude Code Brief (Milestone 1)

## এই প্রজেক্ট কী
একটি Multi-School / Multi-Tenant School Management App। UI প্রোটোটাইপ ইতিমধ্যে তৈরি (`www/index.html`, `www/phase2.html` ... `www/phase5.html`) — Capacitor দিয়ে Android APK হিসেবে বানানো হয়েছে। এখন এই UI-কে **আসল Supabase database + authentication**-এর সাথে যুক্ত করতে হবে।

## Stack
- **Database + Auth**: Supabase (Postgres + Row Level Security)
- **Frontend**: বিদ্যমান HTML/CSS/JS (Capacitor wrapped)। `@supabase/supabase-js` client library ব্যবহার করে সরাসরি frontend থেকে Supabase-এ call করা হবে — আলাদা backend server লাগবে না milestone 1-এ।

## এখন পর্যন্ত যা করা আছে
- `backend/schema.sql` — Supabase-এ চালানোর জন্য প্রস্তুত SQL script। Table: `schools`, `profiles`, `classes`, `student_details`, `notices`, `attendance`। প্রতিটি table-এ Row Level Security policy আছে যাতে এক School আরেক School-এর data কখনো দেখতে না পারে (school_id দিয়ে isolate করা)।
- `www/phase2.html` — School registration + Login-এর UI (এখনো dummy data দিয়ে)।
- `www/phase3.html` — Admin Dashboard-সহ UI (এখনো dummy data দিয়ে)।

## Milestone 1 — ঠিক কী কাজ করতে হবে
1. Supabase project থেকে পাওয়া URL ও anon key দিয়ে frontend-এ Supabase client init করা (`www/js/supabase-client.js` নতুন ফাইল বানিয়ে)।
2. `www/phase2.html`-এর **"Create School"** screen-এর ফর্ম থেকে real data নিয়ে `schools` table-এ insert করা, School ID uniqueness আসলেই check করা (dummy data সরিয়ে)।
3. **"First Admin Setup"** screen থেকে Supabase Auth দিয়ে একটা real user account তৈরি করা (email/mobile + password), এবং `profiles` table-এ role='admin' সহ একটা row বানানো, সেই profile-কে ধাপ ১-এ তৈরি করা school-এর সাথে যুক্ত করা।
4. **"School Login"** screen থেকে real Supabase Auth login করানো — সফল হলে `profiles` table থেকে role ও school_id বের করা।
5. **Admin Dashboard** (`phase3.html`)-এ dummy "২৪ জন শিক্ষক, ৬৪৮ জন শিক্ষার্থী..." সংখ্যাগুলো সরিয়ে, `profiles`/`student_details` table থেকে real count query করে দেখানো (প্রথমে ০ দেখাবে, কারণ এখনো কোনো teacher/student যোগ করা হয়নি — এটাই প্রত্যাশিত, কারণ এখন data সত্যিই database থেকে আসছে)।
6. Attendance submit বাটন থেকে সত্যিই `attendance` table-এ insert হওয়া।

## এখনো যা করার দরকার নেই (পরের milestone-এ)
- Teacher/Student/Parent module (Phase 4, 5)-এর পূর্ণ backend সংযোগ
- Homework, Exam/Result tables ও logic
- OTP-ভিত্তিক verification, password reset flow
- Notice-এর target_role অনুযায়ী filtering UI

## গুরুত্বপূর্ণ নিয়ম যা মানতে হবে
- **কোনো query কখনো school_id ছাড়া চলবে না** — সবসময় logged-in user-এর নিজের school_id দিয়ে filter হবে (schema-র RLS policy এটা এমনিতেই জোর করে, কিন্তু frontend code-এও এটা মাথায় রাখতে হবে)।
- App ID (`com.yourschool.app`) কখনো বদলানো যাবে না।
- UI-এর visual design (blue+white theme, layout) অপরিবর্তিত থাকবে — শুধু dummy data-এর জায়গায় real data বসবে।
