# Your School App — Claude Code Brief (Milestone 2 শুরু করার জন্য)

## এখন পর্যন্ত যা সত্যিই কাজ করে (Milestone 1 — সম্পন্ন)
- `backend/schema.sql` — Supabase database schema, Row Level Security সহ।
- `www/phase2.html`:
  - "Create Your School" — সত্যিই `schools` table-এ insert করে, School ID uniqueness check করে।
  - "First Admin Setup" — Supabase Auth দিয়ে সত্যিই account তৈরি করে (`profiles` table-এ role='admin' সহ)।
  - "School Login" — Supabase Auth দিয়ে সত্যিই login করে, সফল হলে `phase3.html`-এ redirect করে।
- `www/phase3.html` dashboard screen:
  - Logged-in profile ও school-এর real নাম/আইডি দেখায়।
  - শিক্ষক/শিক্ষার্থী/অভিভাবক/ক্লাস-এর real count (database থেকে) দেখায়।
  - আজকের attendance percentage `attendance` table থেকে হিসাব করে (কোনো data না থাকলে "কোনো ডেটা নেই" দেখায়)।
  - কোনো session না থাকলে অথবা role admin না হলে স্বয়ংক্রিয়ভাবে সামলায়।

## এখনো যা dummy data দিয়ে চলছে (পরের কাজ)
1. **Phase 3-এর বাকি screen** (`www/phase3.html`-এর ভেতরেই): Teacher Management, Student Management, Parent Management, Class & Section, Subjects, Routine, Attendance marking, Exam & Result, Notice — এগুলোর তালিকা ও "+ নতুন..." বাটন এখনো শুধু UI, কোনো database call নেই।
2. **Phase 4 (`www/phase4.html`)** ও **Phase 5 (`www/phase5.html`)** — সম্পূর্ণ dummy data, কোনো backend সংযোগ নেই। Teacher/Student login flow এখনো নেই (শুধু Admin login কাজ করে)।
3. Homework, Exam, Marks-এর জন্য কোনো table এখনো `schema.sql`-এ নেই — এগুলো নতুন table হিসেবে যোগ করতে হবে।

## পরের কাজ শুরু করার প্যাটার্ন (Phase 3 → Teacher Management দিয়ে শুরু করা ভালো)
`www/phase3.html`-এর `teachers` screen-এ:
1. একটা "+ Add Teacher" ফর্ম বানানো (Full Name, Mobile, Subject, Class range, Password) — Phase 2-এর "First Admin Setup"-এর মতোই Supabase Auth দিয়ে account তৈরি করে `profiles` table-এ role='teacher' সহ insert করবে, একই `school_id` যুক্ত থাকবে (logged-in admin-এর school_id থেকে নেওয়া, hardcode নয়)।
2. তালিকায় dummy ৪ জনের বদলে real query: `profiles` table থেকে role='teacher' ও school_id=(logged-in admin-এর school_id) দিয়ে filter করে দেখানো।
3. একই প্যাটার্ন Student Management (role='student', সাথে class_id) ও Parent Management (role='parent')-এর জন্য পুনরাবৃত্তি করা।

## গুরুত্বপূর্ণ নিয়ম (অপরিবর্তিত)
- কোনো query কখনো school_id ছাড়া চলবে না — সবসময় **logged-in user-এর নিজের** school_id ব্যবহার করতে হবে (session থেকে profile fetch করে বের করা, hardcode বা URL parameter থেকে নয়)।
- App ID (`com.yourschool.app`) কখনো বদলানো যাবে না।
- Visual design অপরিবর্তিত থাকবে — শুধু dummy data-এর জায়গায় real data ও real onclick handler বসবে (Phase 2/3-dashboard-এ যেভাবে করা হয়েছে, ঠিক সেই প্যাটার্ন অনুসরণ করা)।
- Supabase-এ প্রতিটা নতুন role তৈরির সময় "Confirm email" বন্ধ আছে কিনা মনে করিয়ে দেওয়া — নাহলে login fail করবে।
