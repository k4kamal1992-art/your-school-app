# Your School App — সম্পূর্ণ প্রজেক্ট (Phase 1–5 + Milestone 1 backend)

এই প্রজেক্টে এখন দুই ধরনের screen আছে:

- **Phase 1, 4, 5** — এখনো শুধু ডিজাইন-মকআপ (dummy data, বাটনে চাপলে শুধু পরের screen দেখায়)।
- **Phase 2 ও Phase 3-এর Dashboard** — **real Supabase database ও login-এর সাথে যুক্ত করা হয়েছে** (Milestone 1)। অর্থাৎ School তৈরি করা, Admin account তৈরি করা, real Login, এবং Admin Dashboard-এ real সংখ্যা (শুরুতে ০, কারণ এখনো কোনো Teacher/Student যোগ করা হয়নি) — এগুলো এখন সত্যিই কাজ করে, যদি আপনি নিচের সেটআপ করেন।

---

## ধাপ ১ — Supabase Project তৈরি করুন

1. [supabase.com](https://supabase.com)-এ অ্যাকাউন্ট খুলুন, "New project" দিয়ে একটা project বানান।
2. Project খুলে বামপাশের মেনু থেকে **SQL Editor -> New query**-তে যান। এই repo-র `backend/schema.sql` ফাইলের পুরো কন্টেন্ট copy-paste করে **Run** করুন। এতে database table (schools, profiles, classes, ইত্যাদি) ও security rule তৈরি হয়ে যাবে।
3. **Authentication -> Providers -> Email**-এ গিয়ে **"Confirm email" অপশনটা বন্ধ (disable) করে দিন।**
   > এটা **অবশ্যই করতে হবে** — আমরা real email পাঠাচ্ছি না (School ID + Mobile দিয়ে login সিস্টেম বানানো), তাই email confirmation চালু থাকলে Login কখনো কাজ করবে না।
4. **Project Settings -> API**-এ গিয়ে **Project URL** ও **anon public key** কপি করে রাখুন।

## ধাপ ২ — config.js-এ Key বসান

`www/js/config.js` ফাইলটা খুলুন (GitHub-এই সরাসরি edit করা যায় — ফাইলে ক্লিক করে পেন্সিল আইকনে চাপুন), এবং এই দুই লাইন বদলে আপনার আসল মান বসান:

```js
window.SUPABASE_URL = "YOUR_SUPABASE_URL_HERE";
window.SUPABASE_ANON_KEY = "YOUR_SUPABASE_ANON_KEY_HERE";
```

Commit করুন।

## ধাপ ৩ — zip আপলোড ও APK build

আগের নিয়মেই — পুরো `your-school-app` ফোল্ডারটা zip করে GitHub repo-তে upload করুন (অথবা যদি আগে থেকেই repo-তে ফাইল থাকে, শুধু বদলানো ফাইলগুলো — `www/phase2.html`, `www/phase3.html`, `www/js/config.js`, `backend/schema.sql` — replace/upload করুন)। `.github/workflows/build-apk.yml` আগেরটাই থাকবে, কিছু বদলাতে হবে না। Actions ট্যাবে build হবে, Artifacts থেকে নতুন APK ডাউনলোড করুন।

## ধাপ ৪ — টেস্ট করুন (এখন স্বাভাবিক App-এর মতোই, কোনো manual বাটন লাগবে না)

App খুলুন — এটাই এখন real flow:

1. **Splash → Onboarding (Next/Skip করে এগোন) → Terms & Conditions → Login screen**-এ পৌঁছাবেন (এটা Phase 1-এর নিজস্ব screen, কিন্তু এর "Login" বাটন ও "Create School" লিংক এখন সরাসরি real Phase 2-তে নিয়ে যায়)।
2. একাউন্ট না থাকলে **"Create School"** চাপুন → real "Create Your School" ফর্ম পূরণ করুন → School real database-এ তৈরি হবে।
3. এরপর **"Set Up School Admin"**-এ নিজের নাম, মোবাইল, পাসওয়ার্ড দিয়ে real Admin account তৈরি করুন।
4. এবার সেই School ID + মোবাইল + পাসওয়ার্ড দিয়ে **Login** করুন।
5. সফল হলে স্বয়ংক্রিয়ভাবে real **Admin Dashboard**-এ চলে যাবে, যেখানে "শিক্ষক: ০, শিক্ষার্থী: ০..." দেখাবে — এটাই প্রমাণ যে এখন সত্যিই database থেকে real (এখনো খালি) data আসছে।

> Phase 4 ও Phase 5 (Teacher/Student module)-এর ডিজাইন এখনো এই real flow-এর সাথে যুক্ত করা হয়নি (Teacher/Student login এখনো বানানো হয়নি), তাই এই মুহূর্তে App-এর ভেতর থেকে সেগুলোতে পৌঁছানো যাবে না — সেটা পরের ধাপে যুক্ত হবে।

---

## এই project-এর কাঠামো

```
your-school-app/
├── www/
│   ├── index.html         ← Phase 1 — App Foundation (এখনো ডিজাইন-মকআপ)
│   ├── phase2.html        ← Phase 2 — School Registration + Login (✅ real backend)
│   ├── phase3.html        ← Phase 3 — School Admin (✅ Dashboard-এ real data; বাকি screen এখনো মকআপ)
│   ├── phase4.html        ← Phase 4 — Teacher Module (এখনো ডিজাইন-মকআপ)
│   ├── phase5.html        ← Phase 5 — Student Module (এখনো ডিজাইন-মকআপ)
│   └── js/
│       └── config.js      ← Supabase URL ও Key এখানে বসাতে হবে
├── backend/
│   ├── schema.sql          ← Supabase-এ চালানোর জন্য database script
│   └── CLAUDE_CODE_BRIEF.md← পরের ধাপগুলোর জন্য Claude Code-কে দেওয়ার ব্রিফ
├── package.json
├── capacitor.config.json
├── .github/workflows/build-apk.yml
└── README.md
```

- **App ID**: `com.yourschool.app` — কখনো বদলাবেন না।

## এরপর কী

Phase 3-এর বাকি screen (Teacher/Student/Parent তালিকা, Attendance marking, Notice ইত্যাদি) এবং Phase 4/5 এখনো dummy data দিয়ে চলছে। `backend/CLAUDE_CODE_BRIEF.md`-এ পরের ধাপগুলোর বর্ণনা আছে — Claude Code দিয়ে ধাপে ধাপে এগুলো real করা যাবে।
