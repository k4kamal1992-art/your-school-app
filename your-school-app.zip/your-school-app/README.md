# Your School App — Phase 1 (App Foundation)

এই folder-টি একটি সম্পূর্ণ **buildable Android project shell**। এখানে আপাতত Phase 1-এর ১০টি screen (Splash, Onboarding ×3, Login, OTP, Reset Password, Language, Terms & Conditions, App Introduction) `www/index.html`-এর ভেতরে আছে। GitHub-এ push করলেই **GitHub Actions** automatic APK বানিয়ে দেবে — আপনার কম্পিউটারে Android Studio বা Gradle install করার দরকার নেই।

---

## ধাপ ১ — GitHub-এ Repository তৈরি করুন

1. github.com-এ একটি নতুন **public বা private repository** তৈরি করুন (যেমন: `your-school-app`)।
2. এই zip-এর ভেতরের **সব ফাইল ও ফোল্ডার** (folder সহ, `.github` folder-টিও) সেই repository-তে upload/push করুন।

   - সহজ উপায়: GitHub repo page-এ "Add file → Upload files" দিয়ে পুরো zip-এর content ধরে drag করে দিন।
   - অথবা কমান্ড লাইনে:
     ```
     git init
     git add .
     git commit -m "Phase 1 - App Foundation"
     git branch -M main
     git remote add origin https://github.com/<your-username>/your-school-app.git
     git push -u origin main
     ```

## ধাপ ২ — APK build নিজে থেকেই শুরু হবে

Push করার সাথে সাথে repo-র উপরে **Actions** ট্যাবে যান। সেখানে `Build Android APK` নামে একটি workflow run হতে দেখবেন (৩-৫ মিনিট সময় লাগতে পারে)।

## ধাপ ৩ — APK ডাউনলোড করুন

Workflow run শেষ হলে, সেই run-এর পেজে নিচের দিকে **Artifacts** অংশে `your-school-app-debug-apk` নামে একটি zip পাবেন। সেটি ডাউনলোড করলে ভেতরে `app-debug.apk` পাবেন — এটি সরাসরি Android ফোনে install করে test করা যাবে।

> এটি একটি **debug APK** — টেস্ট করার জন্য যথেষ্ট, কিন্তু Play Store-এ দেওয়ার আগে signed **release APK/AAB** বানাতে হবে (Phase শেষ হলে সেটা নিয়ে আলাদাভাবে সাহায্য করব)।

---

## এই project-এর কাঠামো

```
your-school-app/
├── www/
│   ├── index.html         ← Phase 1 — App Foundation (10 screens)
│   ├── phase2.html        ← Phase 2 — School Registration + Login (8 screens)
│   ├── phase3.html        ← Phase 3 — School Admin (10 screens)
│   ├── phase4.html        ← Phase 4 — Teacher Module (7 screens)
│   └── phase5.html        ← Phase 5 — Student Module (6 screens)
├── package.json           ← Capacitor dependency তালিকা
├── capacitor.config.json  ← App ID, App Name, webDir
├── .github/workflows/
│   └── build-apk.yml      ← GitHub Actions — এটাই APK বানায়
└── README.md
```

App খুললে প্রথমে Phase 1 (`index.html`) দেখা যাবে। প্রতিটি screen-এর উপরে ছোট্ট **Phase 1 / Phase 2 / Phase 3 / Phase 4 / Phase 5** ট্যাব দেওয়া আছে, সেখান থেকে সরাসরি অন্য Phase-এ যাওয়া যাবে — টেস্ট করার সুবিধার জন্য।

- **App ID**: `com.yourschool.app` — এটাই App-এর স্থায়ী পরিচয় (Android package name)। **Phase 2, 3 ... শেষ পর্যন্ত এই App ID কখনো বদলাবেন না**, নাহলে Play Store একে আলাদা App হিসেবে ধরবে।
- **App Name**: `Your School App` — চাইলে `capacitor.config.json`-এ বদলাতে পারবেন।

---

## Phase 2 থেকে যেভাবে যোগ করবেন

পরবর্তী Phase-এর screen তৈরি হয়ে গেলে:

1. নতুন screen-গুলো একইভাবে `www/index.html`-এ (বা `www/` folder-এর ভেতরে নতুন আলাদা .html ফাইল হিসেবে) যোগ করে দেব।
2. আপনি শুধু GitHub repo-তে updated `www/` folder push করবেন।
3. GitHub Actions আবার automatic নতুন APK বানিয়ে দেবে — বারবার নতুন করে project সেটআপ করার দরকার নেই।

এভাবে Phase 1 → Phase 8 পর্যন্ত একই repository আস্তে আস্তে সম্পূর্ণ App-এ পরিণত হবে।
