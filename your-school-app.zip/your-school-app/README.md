# Your School App — সম্পূর্ণ প্রজেক্ট (Phase 1–5)

এই folder-টি একটি সম্পূর্ণ **buildable Android project shell**। `www/` ফোল্ডারে এখন পর্যন্ত তৈরি হওয়া সব Phase-এর screen আছে। GitHub-এ আপলোড করলেই **GitHub Actions** automatic APK বানিয়ে দেবে — আপনার কম্পিউটারে Android Studio বা Gradle install করার দরকার নেই।

**গুরুত্বপূর্ণ:** ফোনে আসল App-এর মতো দেখানোর জন্য প্রতিটি screen থেকে ব্রাউজার-রিভিউ চ্যাট UI (Phase ট্যাব, বর্ণনা প্যানেল, ফোনের ভেতরে আরেকটা ফোনের ছবি) সরিয়ে ফেলা হয়েছে। এখন প্রতিটি .html ফাইল খুললে সরাসরি পুরো স্ক্রিন জুড়ে আসল App-এর screen দেখা যাবে। ডান দিকে ওপরে ছোট্ট গোল **1 2 3 4 5** বাটন আছে যেটা দিয়ে Phase পাল্টানো যায় — টেস্ট করার সুবিধার জন্য (production-এ এটা থাকবে না)।

---

## ধাপ ১ — GitHub Repository তৈরি করুন

github.com-এ একটি নতুন repository তৈরি করুন (যেমন: `your-school-app`)।

## ধাপ ২ — zip ফাইলটি সরাসরি আপলোড করুন

`your-school-app-all-phases.zip` ফাইলটি **extract না করেই** সরাসরি repo-র "Add file → Upload files" দিয়ে আপলোড করে দিন। কোনো সমস্যা নেই — এই প্রজেক্টের workflow zip-কে GitHub-এর সার্ভারেই নিজে থেকে extract করে নেবে (আপনি যেই নামেই zip-টা রাখুন না কেন)।

## ধাপ ৩ — workflow file যোগ করুন (একবারই লাগবে)

Repo-তে "Add file → Create new file" দিয়ে এই path-এ একটা file বানান:

```
.github/workflows/build-apk.yml
```

এই repo-র `.github/workflows/build-apk.yml`-এ যে কন্টেন্ট আছে সেটাই হুবহু paste করুন এবং Commit করুন।

## ধাপ ৪ — APK build

Commit করার সাথে সাথে repo-র **Actions** ট্যাবে `Build Android APK` workflow স্বয়ংক্রিয়ভাবে চলবে (৩-৫ মিনিট লাগে)। শেষ হলে সেই run-এর পেজে **Artifacts** অংশে `your-school-app-debug-apk` পাবেন — ডাউনলোড করে extract করলে ভেতরে `app-debug.apk`, যেটা সরাসরি ফোনে install করা যাবে।

> এটি একটি **debug APK** — টেস্ট করার জন্য যথেষ্ট, Play Store-এ দেওয়ার আগে signed **release APK/AAB** লাগবে (পরে আলাদাভাবে সাহায্য করব)।

---

## এই project-এর কাঠামো

```
your-school-app/
├── www/
│   ├── index.html         ← Phase 1 — App Foundation (10 screens)
│   ├── phase2.html        ← Phase 2 — School Registration + Login (8 screens)
│   ├── phase3.html        ← Phase 3 — School Admin (10 screens)
│   ├── phase4.html        ← Phase 4 — Teacher Module (7 screens)
│   └── phase5.html        ← Phase 5 — Student Module (6 screens)
├── package.json           ← Capacitor dependency তালিকা
├── capacitor.config.json  ← App ID, App Name, webDir
├── .github/workflows/
│   └── build-apk.yml      ← GitHub Actions — এটাই APK বানায় (zip নিজে থেকে unzip করে)
└── README.md
```

- **App ID**: `com.yourschool.app` — এটাই App-এর স্থায়ী পরিচয় (Android package name)। **কখনো এই App ID বদলাবেন না**, নাহলে Play Store একে আলাদা App হিসেবে ধরবে।
- **App Name**: `Your School App` — চাইলে `capacitor.config.json`-এ বদলাতে পারবেন।

---

## পরের Phase যোগ করার সময়

নতুন Phase-এর screen তৈরি হয়ে গেলে আমি নতুন zip দেব — সেই নতুন zip দিয়ে repo-র পুরনো zip file-টা replace (delete করে আবার upload) করলেই যথেষ্ট। `.github/workflows/build-apk.yml` আর বদলানো লাগবে না, এটা এমনভাবে বানানো যাতে ভবিষ্যতের সব Phase-এর জন্যও একইভাবে কাজ করে।
