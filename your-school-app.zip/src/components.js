import React from "react";
import { View, Text, Pressable, TextInput, StyleSheet } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons } from "@expo/vector-icons";
import { C } from "./theme";

export function Logo({light=false}) {
  return (
    <View style={styles.logoWrap}>
      <View style={[styles.logoBox, {backgroundColor: light ? "rgba(255,255,255,.16)" : "#EAF3FF"}]}>
        <Ionicons name="school-outline" size={34} color={light ? "#fff" : C.blue}/>
        <View style={styles.logoCap}><Ionicons name="ribbon-outline" size={12} color={C.orange}/></View>
      </View>
      <Text style={[styles.logoText,{color:light?"#fff":C.text}]}>Your School App</Text>
    </View>
  );
}

export function PrimaryButton({title,onPress,icon}) {
  return <Pressable onPress={onPress} style={({pressed})=>[styles.button, pressed && {opacity:.88, transform:[{scale:.99}]}]}>
    {icon && <Ionicons name={icon} size={18} color="#fff" style={{marginRight:7}}/>}
    <Text style={styles.buttonText}>{title}</Text>
  </Pressable>
}

export function Field({label,placeholder,value,onChangeText,icon="person-outline",secure=false,right}) {
  return <View style={styles.fieldWrap}>
    <Text style={styles.fieldLabel}>{label}</Text>
    <View style={styles.field}>
      <Ionicons name={icon} size={18} color={C.muted}/>
      <TextInput style={styles.input} placeholder={placeholder} placeholderTextColor="#A1AFC0"
        value={value} onChangeText={onChangeText} secureTextEntry={secure}/>
      {right}
    </View>
  </View>
}

export function Header({title,subtitle,onBack,light=false}) {
  return <View style={[styles.header, light && {backgroundColor:C.blue}]}>
    {onBack && <Pressable onPress={onBack} style={styles.back}><Ionicons name="chevron-back" size={25} color={light?"#fff":C.text}/></Pressable>}
    <View style={{flex:1}}>
      <Text style={[styles.headerTitle,{color:light?"#fff":C.text}]}>{title}</Text>
      {subtitle && <Text style={[styles.headerSub,{color:light?"#DCEBFF":C.muted}]}>{subtitle}</Text>}
    </View>
  </View>
}

export function Card({children,style}) { return <View style={[styles.card,style]}>{children}</View> }

export function BottomNav({active="Home",navigation}) {
  const items=[["Home","home-outline","Home"],["Notice","notifications-outline","Notice"],["Profile","person-outline","Profile"],["More","ellipsis-horizontal","More"]];
  return <View style={styles.bottom}>
    {items.map(([label,icon,key])=><Pressable key={key} onPress={()=>key==="Home"&&navigation?.navigate("P2Welcome")} style={styles.navItem}>
      <Ionicons name={icon} size={22} color={active===label?C.blue:"#91A0B2"}/>
      <Text style={[styles.navText,{color:active===label?C.blue:"#91A0B2"}]}>{label}</Text>
    </Pressable>)}
  </View>
}

export const styles=StyleSheet.create({
  screen:{flex:1,backgroundColor:C.bg},
  scroll:{padding:20,paddingBottom:30},
  center:{flex:1,alignItems:"center",justifyContent:"center",padding:24},
  logoWrap:{alignItems:"center"},
  logoBox:{width:70,height:70,borderRadius:20,alignItems:"center",justifyContent:"center",position:"relative"},
  logoCap:{position:"absolute",top:10,right:12},
  logoText:{fontSize:18,fontWeight:"800",marginTop:10},
  header:{paddingHorizontal:20,paddingTop:16,paddingBottom:14,flexDirection:"row",alignItems:"center",backgroundColor:C.bg},
  headerTitle:{fontSize:22,fontWeight:"800"},
  headerSub:{fontSize:12,marginTop:3},
  back:{width:38,height:38,alignItems:"center",justifyContent:"center",marginRight:8},
  button:{height:52,borderRadius:16,backgroundColor:C.blue,alignItems:"center",justifyContent:"center",flexDirection:"row",elevation:2,shadowColor:C.shadow,shadowOpacity:.2,shadowRadius:8},
  buttonText:{color:"#fff",fontSize:15,fontWeight:"800"},
  fieldWrap:{marginBottom:14},
  fieldLabel:{fontSize:12,fontWeight:"700",color:C.text,marginBottom:6},
  field:{height:52,borderRadius:14,borderWidth:1,borderColor:C.border,backgroundColor:"#fff",flexDirection:"row",alignItems:"center",paddingHorizontal:14},
  input:{flex:1,fontSize:14,color:C.text,marginLeft:10},
  card:{backgroundColor:"#fff",borderRadius:18,borderWidth:1,borderColor:C.border,padding:16,shadowColor:C.shadow,shadowOpacity:.13,shadowRadius:12,elevation:2},
  bottom:{height:70,borderTopWidth:1,borderTopColor:C.border,backgroundColor:"#fff",flexDirection:"row",justifyContent:"space-around",alignItems:"center"},
  navItem:{alignItems:"center",justifyContent:"center",minWidth:60},
  navText:{fontSize:10,fontWeight:"700",marginTop:3},
  small:{fontSize:12,color:C.muted,lineHeight:18},
  title:{fontSize:25,fontWeight:"800",color:C.text},
  h2:{fontSize:18,fontWeight:"800",color:C.text},
  iconTile:{width:54,height:54,borderRadius:16,alignItems:"center",justifyContent:"center",marginRight:12}
});
