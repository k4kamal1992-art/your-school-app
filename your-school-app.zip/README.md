# Your School App — Phase 1 + Phase 2 + Phase 3 Prototype

A React Native / Expo prototype containing the approved Phase 1, Phase 2 and Phase 3 school-management screens.

## Included
- Phase 1 — 10 screens
- Phase 2 — 8 screens
- Phase 3 — 10 screens
- Total — **28 screens**
- Consistent blue/white/pastel visual language across all phases
- React Navigation native stack
- Expo + Ionicons + Linear Gradient
- EAS Android preview APK configuration
- GitHub Actions workflow for Android preview builds

## Phase 3 modules
1. Admin Dashboard
2. Teacher Management
3. Student Management
4. Parent / Guardian Management
5. Class & Section Management
6. Subject Management
7. Routine Management
8. Attendance Overview
9. Exams & Results
10. Notices & School Settings

## Run locally
```bash
npm install
npx expo start
```

For Android:
```bash
npm run android
```

For an EAS preview APK:
```bash
npm install -g eas-cli
eas login
eas build -p android --profile preview
```

## Important
This ZIP is a **UI/navigation prototype**, not the production backend.

Not implemented here:
- NestJS API
- Prisma/PostgreSQL database
- Real OTP/SMS delivery
- Production authentication/session handling
- Backend-enforced multi-tenant isolation
- Real school/user CRUD APIs
- Payment gateway
- Push notification infrastructure

Those will be connected during the backend and production implementation phases while preserving the approved UI direction.

## Screen map
See `docs/SCREENS.md` for the complete 28-screen list.
