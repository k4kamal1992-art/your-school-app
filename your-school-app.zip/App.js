import React,{useState} from "react";
import { View, Text, ScrollView, Pressable, SafeAreaView, KeyboardAvoidingView, Platform } from "react-native";
import { NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { Ionicons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import { C } from "./src/theme";
import { Logo, PrimaryButton, Field, Header, Card, BottomNav, styles } from "./src/components";

const Stack=createNativeStackNavigator();

function Screen({children}){return <SafeAreaView style={styles.screen}>{children}</SafeAreaView>}

function P1Splash({navigation}){
 return <LinearGradient colors={[C.blue,"#1595EE"]} style={{flex:1}}>
   <View style={{flex:1,alignItems:"center",justifyContent:"center",padding:28}}>
     <Logo light/>
     <View style={{marginTop:70,alignItems:"center"}}>
       <Ionicons name="school" size={95} color="#fff"/>
       <Text style={{color:"#fff",fontSize:26,fontWeight:"900",marginTop:16}}>Learn • Grow • Succeed</Text>
       <Text style={{color:"#DCEBFF",marginTop:8}}>Smart School Management{"\n"}for a Brighter Future</Text>
     </View>
     <Pressable onPress={()=>navigation.navigate("P1On1")} style={{position:"absolute",bottom:48}}>
       <Text style={{color:"#fff",fontWeight:"800"}}>Tap to continue</Text>
     </Pressable>
   </View>
 </LinearGradient>
}

function Onboard({navigation,index,title,body,icon,next,last=false}){
 return <Screen><View style={{flex:1,padding:24,justifyContent:"space-between"}}>
   <View style={{alignItems:"center",paddingTop:18}}>
     <View style={{height:310,width:"100%",borderRadius:28,backgroundColor:"#EAF4FF",alignItems:"center",justifyContent:"center"}}>
       <Ionicons name={icon} size={120} color={C.blue}/>
     </View>
     <Text style={[styles.title,{textAlign:"center",marginTop:30}]}>{title}</Text>
     <Text style={[styles.small,{textAlign:"center",marginTop:10,fontSize:14}]}>{body}</Text>
   </View>
   <View>
     <View style={{flexDirection:"row",justifyContent:"center",marginBottom:20}}>{[0,1,2].map(i=><View key={i} style={{width:i===index?22:7,height:7,borderRadius:5,backgroundColor:i===index?C.blue:"#C9D5E3",marginHorizontal:4}}/>)}</View>
     <PrimaryButton title={last?"Get Started":"Next"} onPress={()=>navigation.navigate(next)}/>
     <Pressable onPress={()=>navigation.navigate("P1Login")} style={{alignItems:"center",padding:14}}><Text style={{color:C.blue,fontWeight:"700"}}>Skip</Text></Pressable>
   </View>
 </View></Screen>
}

function P1On1(p){return <Onboard {...p} index={0} title="Better Education\nBrighter Future" body="Manage your school, classes, results and more — all in one place." icon="school-outline" next="P1On2"/>}
function P1On2(p){return <Onboard {...p} index={1} title="Smart Management\nFor Every Role" body="Admin, Teacher, Student and Parent — all connected." icon="people-outline" next="P1On3"/>}
function P1On3(p){return <Onboard {...p} index={2} title="Stay Updated\nAlways" body="Get notifications, track progress and never miss important updates." icon="notifications-outline" next="P1Login" last/>}

function P1Login({navigation}){
 return <Screen><ScrollView contentContainerStyle={styles.scroll}>
   <Logo/>
   <Text style={[styles.title,{marginTop:28}]}>Login to your account</Text>
   <View style={{marginTop:25}}>
     <Field label="School ID" placeholder="e.g. ABCHS001" icon="school-outline"/>
     <Field label="Mobile Number" placeholder="e.g. 98XXXXXXXX" icon="phone-portrait-outline"/>
     <Field label="Password" placeholder="Enter password" icon="lock-closed-outline" secure right={<Ionicons name="eye-outline" size={18} color={C.muted}/>}/>
     <PrimaryButton title="Login" icon="log-in-outline" onPress={()=>navigation.navigate("P1HomeIntro")}/>
     <Pressable onPress={()=>navigation.navigate("P1Reset")} style={{alignItems:"center",padding:16}}><Text style={{color:C.blue,fontWeight:"800"}}>Forgot Password?</Text></Pressable>
     <View style={{alignItems:"center",marginVertical:8}}><Text style={styles.small}>OR</Text></View>
     <Pressable onPress={()=>navigation.navigate("P2Create")} style={{alignItems:"center",padding:10}}><Text style={{color:C.blue,fontWeight:"800"}}>Don't have an account?  Create School</Text></Pressable>
   </View>
 </ScrollView></Screen>
}

function P1OTP({navigation}){
 return <Screen><View style={styles.center}>
   <Header title="Verify OTP" subtitle="Enter the 6-digit code sent to your mobile" onBack={()=>navigation.goBack()}/>
   <View style={{width:"100%",alignItems:"center",marginTop:30}}>
     <View style={{flexDirection:"row",gap:8,marginBottom:20}}>{[1,2,3,4,5,6].map(i=><View key={i} style={{width:45,height:52,borderWidth:1,borderColor:C.border,borderRadius:12,backgroundColor:"#fff",alignItems:"center",justifyContent:"center"}}><Text style={{fontSize:18,fontWeight:"800",color:C.text}}>{i===1?"1":""}</Text></View>)}</View>
     <Text style={styles.small}>Resend OTP (00:45)</Text>
     <View style={{width:"100%",marginTop:25}}><PrimaryButton title="Verify" onPress={()=>navigation.navigate("P1Reset")}/></View>
     <Ionicons name="shield-checkmark-outline" size={85} color={C.blue} style={{marginTop:55}}/>
     <Text style={{fontWeight:"800",color:C.text,marginTop:10}}>Your data is safe with us</Text>
   </View>
 </View></Screen>
}

function P1Reset({navigation}){
 return <Screen><ScrollView contentContainerStyle={styles.scroll}>
   <Header title="Reset Password" subtitle="Enter your mobile number to receive your reset code" onBack={()=>navigation.goBack()}/>
   <View style={{marginTop:25}}><Field label="Mobile Number" placeholder="+91 98XXXXXXXX" icon="phone-portrait-outline"/>
   <PrimaryButton title="Send OTP" onPress={()=>navigation.navigate("P1OTP")}/></View>
   <View style={{alignItems:"center",marginTop:80}}><Ionicons name="lock-open-outline" size={80} color={C.blue}/><Text style={{fontWeight:"800",color:C.text,marginTop:12}}>Secure & Simple</Text></View>
 </ScrollView></Screen>
}

function P1Language({navigation}){
 return <Screen><View style={{flex:1,padding:20}}><Header title="Select Language" subtitle="Choose your preferred language" onBack={()=>navigation.goBack()}/>
 {["বাংলা","English"].map((x,i)=><Card key={x} style={{marginTop:12,flexDirection:"row",alignItems:"center"}}><View style={{width:45,height:45,borderRadius:13,backgroundColor:i===0?C.blue:C.purpleBg,alignItems:"center",justifyContent:"center"}}><Text style={{fontWeight:"900",color:i===0?"#fff":C.purple}}>{i===0?"ব":"A"}</Text></View><View style={{flex:1,marginLeft:12}}><Text style={styles.h2}>{x}</Text><Text style={styles.small}>{i===0?"Bengali":"English"}</Text></View><Ionicons name={i===0?"radio-button-on":"radio-button-off"} size={22} color={i===0?C.blue:"#A7B3C1"}/></Card>)}
 <View style={{marginTop:25}}><PrimaryButton title="Next" onPress={()=>navigation.navigate("P1Terms")}/></View>
 </View></Screen>
}

function P1Terms({navigation}){
 return <Screen><ScrollView contentContainerStyle={styles.scroll}><Header title="Terms & Conditions" onBack={()=>navigation.goBack()}/>
 <Card style={{marginTop:15}}><Text style={styles.h2}>Terms & Conditions</Text><Text style={[styles.small,{marginTop:12}]}>1. Introduction{"\n"}This app helps schools manage operations, communication and education services.{"\n\n"}2. User Responsibilities{"\n"}Use this application only for legitimate school-related purposes.{"\n\n"}3. Privacy{"\n"}School data is protected by role-based access and tenant isolation.</Text></Card>
 <View style={{flexDirection:"row",alignItems:"center",marginVertical:18}}><Ionicons name="checkbox" size={23} color={C.blue}/><Text style={{marginLeft:8,color:C.text,fontSize:12,flex:1}}>I agree to the Terms & Conditions and Privacy Policy</Text></View>
 <PrimaryButton title="Continue" onPress={()=>navigation.navigate("P1HomeIntro")}/>
 </ScrollView></Screen>
}

function P1HomeIntro({navigation}){
 return <Screen><LinearGradient colors={[C.blue,"#1682E8"]} style={{padding:20,paddingTop:30,borderBottomLeftRadius:28,borderBottomRightRadius:28}}>
   <View style={{flexDirection:"row",alignItems:"center"}}><Logo light/><View style={{flex:1}}/><Ionicons name="notifications-outline" size={24} color="#fff"/><Ionicons name="person-circle-outline" size={30} color="#fff" style={{marginLeft:12}}/></View>
   <Text style={{color:"#fff",fontSize:24,fontWeight:"900",marginTop:24}}>Welcome to{"\n"}Your School App</Text>
   <Text style={{color:"#DCEBFF",marginTop:6}}>Smart School Management{"\n"}for a Brighter Future</Text>
 </LinearGradient>
 <ScrollView contentContainerStyle={{padding:20}}>
  <Card><View style={{flexDirection:"row",alignItems:"center"}}><Ionicons name="school" size={42} color={C.blue}/><View style={{marginLeft:12,flex:1}}><Text style={styles.h2}>ABC High School</Text><Text style={styles.small}>School ID: ABCHS001</Text></View><Ionicons name="chevron-forward" size={20} color={C.muted}/></View></Card>
  <View style={{flexDirection:"row",flexWrap:"wrap",marginTop:14}}>
   {[["Teachers","people-outline",C.blue],["Students","people",C.green],["Parents","person-outline",C.orange],["Routine","calendar-outline",C.purple],["Attendance","checkmark-circle-outline",C.blue],["Results","document-text-outline",C.green]].map(([t,ic,col])=><Pressable key={t} style={{width:"33.33%",padding:5}}><View style={{backgroundColor:"#fff",borderRadius:16,padding:14,alignItems:"center",borderWidth:1,borderColor:C.border}}><Ionicons name={ic} size={25} color={col}/><Text style={{fontSize:11,fontWeight:"700",color:C.text,marginTop:7}}>{t}</Text></View></Pressable>)}
  </View>
 </ScrollView>
 <BottomNav active="Home" navigation={navigation}/>
 </Screen>
}

/* Phase 2 */
function P2Create({navigation}){
 return <Screen><ScrollView contentContainerStyle={styles.scroll}><Header title="Create Your School" subtitle="Let's get your school registered" onBack={()=>navigation.goBack()}/>
 <View style={{alignItems:"center",marginVertical:10}}><Ionicons name="school-outline" size={70} color={C.blue}/></View>
 <Field label="School Name *" placeholder="ABC High School" icon="school-outline"/>
 <Field label="School ID *" placeholder="ABCHS001" icon="key-outline"/>
 <Field label="School Type *" placeholder="Government" icon="business-outline"/>
 <Field label="Address *" placeholder="123 School Road" icon="location-outline"/>
 <Field label="District *" placeholder="Paschim Medinipur" icon="map-outline"/>
 <Field label="State *" placeholder="West Bengal" icon="flag-outline"/>
 <Field label="Admin Mobile Number *" placeholder="98XXXXXXXX" icon="phone-portrait-outline"/>
 <PrimaryButton title="Create School" icon="add-circle-outline" onPress={()=>navigation.navigate("P2IdCheck")}/>
 </ScrollView></Screen>
}

function P2IdCheck({navigation}){
 return <Screen><ScrollView contentContainerStyle={styles.scroll}><Header title="School ID" subtitle="Enter a unique School ID" onBack={()=>navigation.goBack()}/>
 <Field label="School ID" placeholder="ABCHS001" value="ABCHS001" icon="key-outline"/>
 <Card style={{backgroundColor:C.successBg,borderColor:"#BCEBD6"}}><View style={{flexDirection:"row"}}><Ionicons name="checkmark-circle" size={25} color={C.success}/><View style={{marginLeft:10,flex:1}}><Text style={{fontWeight:"800",color:"#087A50"}}>School ID is available</Text><Text style={styles.small}>You can use this School ID.</Text></View></View></Card>
 <Text style={[styles.h2,{marginTop:25}]}>School Details</Text>
 <View style={{marginTop:12}}>{["School Name  •  ABC High School","School Type  •  Government","District  •  Paschim Medinipur"].map(x=><Card key={x} style={{marginBottom:9}}><Text style={{color:C.text,fontWeight:"700"}}>{x}</Text></Card>)}</View>
 <PrimaryButton title="Continue" onPress={()=>navigation.navigate("P2Success")}/>
 </ScrollView></Screen>
}

function P2Success({navigation}){
 return <Screen><View style={styles.center}>
 <Ionicons name="checkmark-circle" size={105} color={C.success}/><Text style={[styles.title,{textAlign:"center",marginTop:18}]}>School Created{"\n"}Successfully!</Text>
 <Text style={[styles.small,{textAlign:"center",marginTop:8}]}>Your school is now registered on{"\n"}Your School App.</Text>
 <Card style={{width:"100%",marginTop:25}}><Text style={styles.h2}>ABC High School</Text><Text style={[styles.small,{marginTop:6}]}>School ID: ABCHS001</Text><Text style={[styles.small,{marginTop:4}]}>Internal School UUID: 8f71c9a2-3e4f-4d6a-9b2e-1c7d8e9f0a3b</Text></Card>
 <View style={{width:"100%",marginTop:25}}><PrimaryButton title="Continue" onPress={()=>navigation.navigate("P2Admin")}/></View>
 </View></Screen>
}

function P2Admin({navigation}){
 return <Screen><ScrollView contentContainerStyle={styles.scroll}><Header title="Set Up School Admin" subtitle="Create the first administrator for your school" onBack={()=>navigation.goBack()}/>
 <View style={{alignItems:"center",marginBottom:15}}><Ionicons name="person-circle-outline" size={75} color={C.blue}/></View>
 <Field label="Full Name *" placeholder="Md. Rahim Uddin" icon="person-outline"/>
 <Field label="Mobile Number *" placeholder="98XXXXXXXX" icon="phone-portrait-outline"/>
 <Field label="Designation" placeholder="Headmaster" icon="briefcase-outline"/>
 <Field label="Password *" placeholder="Create password" icon="lock-closed-outline" secure/>
 <Field label="Confirm Password *" placeholder="Confirm password" icon="lock-closed-outline" secure/>
 <PrimaryButton title="Create Admin" onPress={()=>navigation.navigate("P2Join")}/>
 <Text style={[styles.small,{textAlign:"center",marginTop:12}]}>Your information is securely protected.</Text>
 </ScrollView></Screen>
}

function P2Join({navigation}){
 return <Screen><ScrollView contentContainerStyle={styles.scroll}><Header title="Join Existing School" subtitle="Already a member? Request to join your school." onBack={()=>navigation.goBack()}/>
 <View style={{alignItems:"center",marginVertical:12}}><Ionicons name="people-outline" size={70} color={C.blue}/></View>
 <Field label="School ID *" placeholder="ABCHS001" icon="school-outline"/>
 <Field label="Mobile Number *" placeholder="98XXXXXXXX" icon="phone-portrait-outline"/>
 <PrimaryButton title="Request to Join" onPress={()=>navigation.navigate("P2Login")}/>
 <Card style={{marginTop:18,backgroundColor:"#EEF7FF"}}><Text style={styles.small}>Your request will be sent to the school admin. You will get a notification once it's approved.</Text></Card>
 </ScrollView></Screen>
}

function P2Login({navigation}){
 return <Screen><ScrollView contentContainerStyle={styles.scroll}><Logo/><Text style={[styles.title,{marginTop:24}]}>School Login</Text><Text style={[styles.small,{marginTop:5}]}>Login to your school account</Text>
 <View style={{marginTop:22}}><Field label="School ID *" placeholder="ABCHS001" icon="school-outline"/><Field label="Mobile Number *" placeholder="98XXXXXXXX" icon="phone-portrait-outline"/><Field label="Password *" placeholder="Password" icon="lock-closed-outline" secure/>
 <PrimaryButton title="Login" onPress={()=>navigation.navigate("P2Verify")}/>
 <Pressable onPress={()=>navigation.navigate("P1Reset")} style={{alignItems:"center",padding:14}}><Text style={{color:C.blue,fontWeight:"800"}}>Forgot Password?</Text></Pressable>
 <View style={{flexDirection:"row",gap:10}}><Pressable onPress={()=>navigation.navigate("P2Join")} style={{flex:1,height:48,borderWidth:1,borderColor:C.blue,borderRadius:14,alignItems:"center",justifyContent:"center"}}><Text style={{color:C.blue,fontWeight:"800"}}>Join Existing School</Text></Pressable><Pressable onPress={()=>navigation.navigate("P2Create")} style={{flex:1,height:48,borderWidth:1,borderColor:C.blue,borderRadius:14,alignItems:"center",justifyContent:"center"}}><Text style={{color:C.blue,fontWeight:"800"}}>Create New School</Text></Pressable></View>
 </View></ScrollView></Screen>
}

function P2Verify({navigation}){
 const steps=["Checking credentials","Finding your school","Verifying user account","Checking role & permissions","Preparing your dashboard"];
 return <Screen><View style={styles.center}><Ionicons name="shield-checkmark" size={95} color={C.blue}/><Text style={[styles.h2,{marginTop:18}]}>Verifying Your Account...</Text><Text style={[styles.small,{textAlign:"center",marginTop:6}]}>Please wait while we verify your school, user and permissions.</Text>
 <View style={{width:"100%",marginTop:30}}>{steps.map((s,i)=><View key={s} style={{flexDirection:"row",alignItems:"center",marginVertical:7}}><Ionicons name={i<4?"checkmark-circle":"ellipse-outline"} size={20} color={i<4?C.blue:"#9DB0C5"}/><Text style={{marginLeft:10,color:C.text,fontSize:13}}>{s}</Text></View>)}</View>
 <View style={{width:"100%",marginTop:25}}><PrimaryButton title="Continue to Dashboard" onPress={()=>navigation.navigate("P2Welcome")}/></View>
 </View></Screen>
}

function P2Welcome({navigation}){
 return <Screen><LinearGradient colors={[C.blue,"#1682E8"]} style={{padding:20,paddingTop:28,borderBottomLeftRadius:28,borderBottomRightRadius:28}}>
 <View style={{flexDirection:"row",alignItems:"center"}}><Logo light/><View style={{flex:1}}/><Ionicons name="notifications-outline" size={24} color="#fff"/><Ionicons name="person-circle-outline" size={30} color="#fff" style={{marginLeft:10}}/></View>
 <Text style={{color:"#fff",fontSize:14,marginTop:22}}>Welcome Back</Text><Text style={{color:"#fff",fontSize:23,fontWeight:"900"}}>Md. Rahim Uddin</Text><Text style={{color:"#DCEBFF",marginTop:3}}>ABC High School  •  ABCHS001</Text>
 </LinearGradient>
 <ScrollView contentContainerStyle={{padding:20}}><Card><View style={{flexDirection:"row",alignItems:"center"}}><Ionicons name="school" size={40} color={C.blue}/><View style={{flex:1,marginLeft:12}}><Text style={styles.h2}>Better Education</Text><Text style={styles.small}>Brighter Future</Text></View><Ionicons name="chevron-forward" size={20} color={C.muted}/></View></Card>
 <View style={{flexDirection:"row",flexWrap:"wrap",marginTop:12}}>{[["Teachers","people-outline",C.blue],["Students","people",C.green],["Classes","grid-outline",C.purple],["Attendance","checkmark-circle-outline",C.blue],["Results","document-text-outline",C.green],["Notices","notifications-outline",C.orange],["Fees","wallet-outline","#E64A9B"],["Homework","book-outline","#10A7C9"],["More","apps-outline",C.purple]].map(([t,ic,col])=><View key={t} style={{width:"33.33%",padding:5}}><View style={{backgroundColor:"#fff",borderRadius:16,padding:13,alignItems:"center",borderWidth:1,borderColor:C.border}}><Ionicons name={ic} size={24} color={col}/><Text style={{fontSize:10,fontWeight:"700",color:C.text,marginTop:6}}>{t}</Text></View></View>)}</View></ScrollView>
 <Pressable onPress={()=>navigation.navigate("P3Dashboard")} style={{marginHorizontal:20,marginBottom:8}}><PrimaryButton title="Open Admin Dashboard" icon="speedometer-outline" onPress={()=>navigation.navigate("P3Dashboard")}/></Pressable>
 <BottomNav active="Home" navigation={navigation}/>
 </Screen>
}


function AdminTop({navigation,title,subtitle}){
 return <View style={{paddingHorizontal:20,paddingTop:18,paddingBottom:12,flexDirection:"row",alignItems:"center"}}>
   <View style={{flex:1}}><Text style={styles.h2}>{title}</Text>{subtitle&&<Text style={styles.small}>{subtitle}</Text>}</View>
   <Pressable style={{width:42,height:42,borderRadius:14,backgroundColor:"#fff",borderWidth:1,borderColor:C.border,alignItems:"center",justifyContent:"center",marginRight:8}}><Ionicons name="notifications-outline" size={21} color={C.text}/></Pressable>
   <Pressable onPress={()=>navigation.navigate("P3Notices")} style={{width:42,height:42,borderRadius:14,backgroundColor:C.blue,alignItems:"center",justifyContent:"center"}}><Ionicons name="settings-outline" size={20} color="#fff"/></Pressable>
 </View>
}

function P3Dashboard({navigation}){
 const stats=[["Teachers","42","people-outline",C.blue,C.purpleBg,"P3Teachers"],["Students","684","people",C.green,C.greenBg,"P3Students"],["Parents","521","person-outline",C.orange,C.orangeBg,"P3Parents"],["Classes","18","grid-outline",C.purple,C.purpleBg,"P3Classes"]];
 return <Screen><AdminTop navigation={navigation} title="Admin Dashboard" subtitle="ABC High School • ABCHS001"/>
  <ScrollView contentContainerStyle={{padding:20,paddingTop:6}}>
   <LinearGradient colors={[C.blue,"#1682E8"]} style={{borderRadius:22,padding:20,marginBottom:16}}>
    <Text style={{color:"#DCEBFF",fontSize:12}}>Good morning, Admin</Text><Text style={{color:"#fff",fontSize:23,fontWeight:"900",marginTop:4}}>Manage your school smarter</Text>
    <Text style={{color:"#DCEBFF",fontSize:12,marginTop:8}}>All your school operations in one place.</Text>
   </LinearGradient>
   <View style={{flexDirection:"row",flexWrap:"wrap"}}>{stats.map(([t,v,ic,col,bg,to])=><Pressable key={t} onPress={()=>navigation.navigate(to)} style={{width:"50%",padding:5}}><Card style={{padding:14}}><View style={{flexDirection:"row",alignItems:"center"}}><View style={[styles.iconTile,{width:44,height:44,backgroundColor:bg,marginRight:10}]}><Ionicons name={ic} size={23} color={col}/></View><View><Text style={{fontSize:22,fontWeight:"900",color:C.text}}>{v}</Text><Text style={styles.small}>{t}</Text></View></View></Card></Pressable>)}</View>
   <Text style={[styles.h2,{marginTop:18,marginBottom:8}]}>Quick Management</Text>
   <View style={{flexDirection:"row",flexWrap:"wrap"}}>{[["Routine","calendar-outline",C.purple,"P3Routine"],["Attendance","checkmark-circle-outline",C.blue,"P3Attendance"],["Exams & Results","document-text-outline",C.green,"P3Exams"],["Notices","megaphone-outline",C.orange,"P3Notices"]].map(([t,ic,col,to])=><Pressable key={t} onPress={()=>navigation.navigate(to)} style={{width:"50%",padding:5}}><Card style={{alignItems:"center",paddingVertical:18}}><Ionicons name={ic} size={29} color={col}/><Text style={{fontWeight:"800",color:C.text,marginTop:8}}>{t}</Text></Card></Pressable>)}</View>
   <Card style={{marginTop:14,backgroundColor:C.orangeBg,borderColor:"#F6D58A"}}><View style={{flexDirection:"row",alignItems:"center"}}><Ionicons name="alert-circle-outline" size={26} color={C.orange}/><View style={{flex:1,marginLeft:10}}><Text style={{fontWeight:"800",color:C.text}}>3 pending requests</Text><Text style={styles.small}>Teacher and parent requests need review.</Text></View><Ionicons name="chevron-forward" size={20} color={C.muted}/></View></Card>
  </ScrollView><BottomNav active="Home" navigation={navigation}/></Screen>
}

const AdminListHeader=({title,subtitle,onBack,action,onAction})=><View><Header title={title} subtitle={subtitle} onBack={onBack}/>{action&&<Pressable onPress={onAction} style={{position:"absolute",right:20,top:17,width:42,height:42,borderRadius:13,backgroundColor:C.blue,alignItems:"center",justifyContent:"center"}}><Ionicons name="add" size={24} color="#fff"/></Pressable>}</View>;

function P3Teachers({navigation}){
 const rows=[["Md. Rahim Uddin","T001","Mathematics","Class 10-A",C.blue],["Sana Parvin","T014","English","Class 9-B",C.purple],["Abdul Karim","T022","Science","Class 8-A",C.green],["Rukhsana Begum","T031","Bengali","Class 7-C",C.orange]];
 return <Screen><AdminListHeader title="Teacher Management" subtitle="42 teachers • Active 40" onBack={()=>navigation.goBack()} action onAction={()=>{}}/><ScrollView contentContainerStyle={{padding:20,paddingTop:5}}><Field label="Search Teacher" placeholder="Name, Teacher ID or mobile" icon="search-outline"/><Card style={{marginBottom:12,backgroundColor:"#EEF6FF"}}><Text style={{color:C.blue,fontWeight:"800"}}>Teacher access</Text><Text style={[styles.small,{marginTop:3}]}>Assign subjects, classes and account status from this module.</Text></Card>{rows.map(r=><Card key={r[1]} style={{marginBottom:10}}><View style={{flexDirection:"row",alignItems:"center"}}><View style={[styles.iconTile,{backgroundColor:"#EAF3FF"}]}><Ionicons name="person" size={25} color={r[4]}/></View><View style={{flex:1}}><Text style={styles.h2}>{r[0]}</Text><Text style={styles.small}>{r[1]} • {r[2]}</Text><Text style={[styles.small,{marginTop:2}]}>{r[3]}</Text></View><Ionicons name="chevron-forward" size={20} color={C.muted}/></View></Card>)}</ScrollView></Screen>
}

function P3Students({navigation}){
 const rows=[["Ayan Khan","S00124","Class 10-A","Guardian: Salma Khan"],["Jannat Ara","S00131","Class 9-B","Guardian: Md. Karim"],["Rafiul Islam","S00202","Class 8-A","Guardian: Rukhsana"]];
 return <Screen><AdminListHeader title="Student Management" subtitle="684 students • 18 classes" onBack={()=>navigation.goBack()} action onAction={()=>{}}/><ScrollView contentContainerStyle={{padding:20,paddingTop:5}}><Field label="Search Student" placeholder="Name, Student ID or mobile" icon="search-outline"/><View style={{flexDirection:"row",gap:8,marginBottom:12}}>{["All","Class","Section"].map(x=><View key={x} style={{flex:1,height:40,borderRadius:12,borderWidth:1,borderColor:C.border,backgroundColor:"#fff",alignItems:"center",justifyContent:"center"}}><Text style={{fontSize:12,fontWeight:"700",color:C.text}}>{x}</Text></View>)}</View>{rows.map(r=><Card key={r[1]} style={{marginBottom:10}}><View style={{flexDirection:"row",alignItems:"center"}}><View style={[styles.iconTile,{backgroundColor:C.greenBg}]}><Ionicons name="school" size={25} color={C.green}/></View><View style={{flex:1}}><Text style={styles.h2}>{r[0]}</Text><Text style={styles.small}>{r[1]} • {r[2]}</Text><Text style={[styles.small,{marginTop:2}]}>{r[3]}</Text></View><Ionicons name="chevron-forward" size={20} color={C.muted}/></View></Card>)}</ScrollView></Screen>
}

function P3Parents({navigation}){
 const rows=[["Salma Khan","P00118","2 children","98XXXXXX12"],["Md. Karim","P00204","1 child","98XXXXXX45"],["Rukhsana Begum","P00271","3 children","98XXXXXX78"]];
 return <Screen><AdminListHeader title="Parent / Guardian" subtitle="521 registered guardians" onBack={()=>navigation.goBack()} action onAction={()=>{}}/><ScrollView contentContainerStyle={{padding:20,paddingTop:5}}><Field label="Search Parent" placeholder="Name, Parent ID or mobile" icon="search-outline"/>{rows.map(r=><Card key={r[1]} style={{marginBottom:10}}><View style={{flexDirection:"row",alignItems:"center"}}><View style={[styles.iconTile,{backgroundColor:C.orangeBg}]}><Ionicons name="people" size={25} color={C.orange}/></View><View style={{flex:1}}><Text style={styles.h2}>{r[0]}</Text><Text style={styles.small}>{r[1]} • {r[2]}</Text><Text style={styles.small}>{r[3]}</Text></View><Ionicons name="chevron-forward" size={20} color={C.muted}/></View></Card>)}<Card style={{marginTop:2,backgroundColor:"#F1F7FF"}}><Text style={{fontWeight:"800",color:C.text}}>Guardian linking</Text><Text style={[styles.small,{marginTop:4}]}>One guardian can be linked to multiple children within the same school.</Text></Card></ScrollView></Screen>
}

function P3Classes({navigation}){
 const rows=[["Class 10","A • B • C","3 sections","18 teachers"],["Class 9","A • B • C","3 sections","16 teachers"],["Class 8","A • B • C","3 sections","15 teachers"],["Class 7","A • B • C","3 sections","14 teachers"]];
 return <Screen><AdminListHeader title="Class & Section" subtitle="18 classes • 42 class teachers" onBack={()=>navigation.goBack()} action onAction={()=>{}}/><ScrollView contentContainerStyle={{padding:20,paddingTop:5}}>{rows.map((r,i)=><Card key={r[0]} style={{marginBottom:10}}><View style={{flexDirection:"row",alignItems:"center"}}><View style={[styles.iconTile,{backgroundColor:i%2?C.purpleBg:"#EAF3FF"}]}><Ionicons name="grid" size={25} color={i%2?C.purple:C.blue}/></View><View style={{flex:1}}><Text style={styles.h2}>{r[0]}</Text><Text style={styles.small}>{r[1]} • {r[2]}</Text><Text style={styles.small}>{r[3]}</Text></View><Ionicons name="chevron-forward" size={20} color={C.muted}/></View></Card>)}<PrimaryButton title="Create New Class / Section" icon="add-circle-outline" onPress={()=>{}}/></ScrollView></Screen>
}

function P3Subjects({navigation}){
 const rows=[["Bengali","Class 1–10","Core","12 teachers"],["English","Class 1–10","Core","11 teachers"],["Mathematics","Class 1–10","Core","10 teachers"],["Science","Class 5–10","Core","8 teachers"],["Computer Applications","Class 6–10","Optional","4 teachers"]];
 return <Screen><AdminListHeader title="Subject Management" subtitle="School-defined curriculum" onBack={()=>navigation.goBack()} action onAction={()=>{}}/><ScrollView contentContainerStyle={{padding:20,paddingTop:5}}><Card style={{backgroundColor:C.purpleBg,borderColor:"#D9D0FF",marginBottom:12}}><Text style={{fontWeight:"800",color:C.purple}}>Flexible subjects</Text><Text style={[styles.small,{marginTop:4}]}>Subjects are created and managed by this school — not hard-coded by the platform.</Text></Card>{rows.map(r=><Card key={r[0]} style={{marginBottom:10}}><View style={{flexDirection:"row",alignItems:"center"}}><View style={[styles.iconTile,{backgroundColor:"#EEF6FF"}]}><Ionicons name="book-outline" size={25} color={C.blue}/></View><View style={{flex:1}}><Text style={styles.h2}>{r[0]}</Text><Text style={styles.small}>{r[1]} • {r[2]}</Text><Text style={styles.small}>{r[3]}</Text></View><Ionicons name="chevron-forward" size={20} color={C.muted}/></View></Card>)}</ScrollView></Screen>
}

function P3Routine({navigation}){
 const periods=[["08:00 – 08:45","Mathematics","Md. Rahim","Room 101"],["08:45 – 09:30","English","Sana Parvin","Room 101"],["09:45 – 10:30","Science","Abdul Karim","Lab 1"],["10:30 – 11:15","Bengali","Rukhsana","Room 101"]];
 return <Screen><AdminListHeader title="Routine Management" subtitle="Class 10-A • Monday" onBack={()=>navigation.goBack()} action onAction={()=>{}}/><ScrollView contentContainerStyle={{padding:20,paddingTop:5}}><View style={{flexDirection:"row",gap:7,marginBottom:14}}>{["Mon","Tue","Wed","Thu","Fri"].map((d,i)=><View key={d} style={{flex:1,height:42,borderRadius:12,backgroundColor:i===0?C.blue:"#fff",borderWidth:1,borderColor:i===0?C.blue:C.border,alignItems:"center",justifyContent:"center"}}><Text style={{fontSize:11,fontWeight:"800",color:i===0?"#fff":C.text}}>{d}</Text></View>)}</View>{periods.map((r,i)=><Card key={r[0]} style={{marginBottom:10}}><View style={{flexDirection:"row",alignItems:"center"}}><View style={{width:68,alignItems:"center"}}><Text style={{fontWeight:"900",color:C.blue,fontSize:12}}>{i+1}</Text><Text style={styles.small}>{r[0]}</Text></View><View style={{height:45,width:1,backgroundColor:C.border,marginHorizontal:12}}/><View style={{flex:1}}><Text style={styles.h2}>{r[1]}</Text><Text style={styles.small}>{r[2]} • {r[3]}</Text></View><Ionicons name="create-outline" size={20} color={C.muted}/></View></Card>)}<PrimaryButton title="Publish Routine" icon="checkmark-circle-outline" onPress={()=>{}}/></ScrollView></Screen>
}

function P3Attendance({navigation}){
 return <Screen><AdminListHeader title="Attendance Overview" subtitle="School-wide attendance" onBack={()=>navigation.goBack()}/><ScrollView contentContainerStyle={{padding:20,paddingTop:5}}><Card style={{alignItems:"center",paddingVertical:22}}><Text style={styles.small}>Today’s Attendance</Text><Text style={{fontSize:48,fontWeight:"900",color:C.blue,marginTop:4}}>94.6%</Text><Text style={{color:C.green,fontWeight:"800"}}>646 Present • 38 Absent</Text></Card><Text style={[styles.h2,{marginTop:18,marginBottom:8}]}>Class-wise breakdown</Text>{[["Class 10","96.2%","118/122",C.green],["Class 9","94.8%","113/119",C.blue],["Class 8","92.5%","111/120",C.orange],["Class 7","95.1%","116/122",C.green]].map(r=><Card key={r[0]} style={{marginBottom:9}}><View style={{flexDirection:"row",alignItems:"center"}}><View style={{flex:1}}><Text style={styles.h2}>{r[0]}</Text><Text style={styles.small}>{r[2]} present</Text></View><Text style={{fontSize:18,fontWeight:"900",color:r[3]}}>{r[1]}</Text></View><View style={{height:7,borderRadius:5,backgroundColor:"#EAF0F6",marginTop:10,overflow:"hidden"}}><View style={{height:7,width:r[1],backgroundColor:r[3]}}/></View></Card>)}<Card style={{marginTop:5,backgroundColor:"#EEF6FF"}}><Text style={{fontWeight:"800",color:C.text}}>Admin view</Text><Text style={[styles.small,{marginTop:4}]}>Teachers mark attendance; Admin monitors school-wide status and reports.</Text></Card></ScrollView></Screen>
}

function P3Exams({navigation}){
 const exams=[["First Term Examination","12 Subjects","Published",C.green],["Unit Test 2","8 Subjects","Draft",C.orange],["Annual Examination","12 Subjects","Scheduled",C.blue]];
 return <Screen><AdminListHeader title="Exams & Results" subtitle="Create, publish and manage results" onBack={()=>navigation.goBack()} action onAction={()=>{}}/><ScrollView contentContainerStyle={{padding:20,paddingTop:5}}>{exams.map(e=><Card key={e[0]} style={{marginBottom:10}}><View style={{flexDirection:"row",alignItems:"center"}}><View style={[styles.iconTile,{backgroundColor:e[3]===C.green?C.greenBg:e[3]===C.orange?C.orangeBg:"#EAF3FF"}]}><Ionicons name="document-text-outline" size={25} color={e[3]}/></View><View style={{flex:1}}><Text style={styles.h2}>{e[0]}</Text><Text style={styles.small}>{e[1]} • {e[2]}</Text></View><Ionicons name="chevron-forward" size={20} color={C.muted}/></View></Card>)}<Text style={[styles.h2,{marginTop:8,marginBottom:8}]}>Result controls</Text><View style={{flexDirection:"row",flexWrap:"wrap"}}>{[["Marks Entry","create-outline",C.blue],["Publish Result","cloud-upload-outline",C.green],["Lock Result","lock-closed-outline",C.purple],["Reports","bar-chart-outline",C.orange]].map(([t,ic,col])=><View key={t} style={{width:"50%",padding:5}}><Card style={{alignItems:"center",paddingVertical:18}}><Ionicons name={ic} size={28} color={col}/><Text style={{fontWeight:"800",color:C.text,marginTop:7}}>{t}</Text></Card></View>)}</View></ScrollView></Screen>
}

function P3Notices({navigation}){
 const notices=[["School will remain closed on Friday","All Users","Today • 09:15 AM",C.blue],["Parent-Teacher Meeting","Parents","Tomorrow • 04:00 PM",C.orange],["Unit Test 2 Schedule Published","Class 8–10","Yesterday • 06:30 PM",C.green]];
 return <Screen><AdminListHeader title="Notices" subtitle="Create and target school announcements" onBack={()=>navigation.goBack()} action onAction={()=>{}}/><ScrollView contentContainerStyle={{padding:20,paddingTop:5}}><Card style={{backgroundColor:"#EEF6FF",marginBottom:14}}><Text style={{fontWeight:"800",color:C.blue}}>Audience targeting</Text><Text style={[styles.small,{marginTop:4}]}>Send notices to everyone, teachers, students, parents or a specific class/section.</Text></Card>{notices.map(n=><Card key={n[0]} style={{marginBottom:10}}><View style={{flexDirection:"row",alignItems:"flex-start"}}><View style={[styles.iconTile,{width:46,height:46,backgroundColor:n[3]===C.orange?C.orangeBg:n[3]===C.green?C.greenBg:"#EAF3FF"}]}><Ionicons name="megaphone-outline" size={23} color={n[3]}/></View><View style={{flex:1}}><Text style={styles.h2}>{n[0]}</Text><Text style={styles.small}>{n[1]} • {n[2]}</Text></View><Ionicons name="ellipsis-vertical" size={20} color={C.muted}/></View></Card>)}<PrimaryButton title="Create New Notice" icon="add-circle-outline" onPress={()=>{}}/><Text style={[styles.h2,{marginTop:24}]}>School Settings</Text><Pressable onPress={()=>navigation.navigate("P3Notices")}><Card style={{marginTop:9}}><View style={{flexDirection:"row",alignItems:"center"}}><Ionicons name="settings-outline" size={25} color={C.blue}/><View style={{flex:1,marginLeft:12}}><Text style={styles.h2}>School Profile & Settings</Text><Text style={styles.small}>Identity, academic year, language, notifications and security</Text></View><Ionicons name="chevron-forward" size={20} color={C.muted}/></View></Card></Pressable></ScrollView></Screen>
}

function App(){
 return <NavigationContainer><Stack.Navigator screenOptions={{headerShown:false,animation:"slide_from_right"}}>
  <Stack.Screen name="P1Splash" component={P1Splash}/>
  <Stack.Screen name="P1On1" component={P1On1}/><Stack.Screen name="P1On2" component={P1On2}/><Stack.Screen name="P1On3" component={P1On3}/>
  <Stack.Screen name="P1Login" component={P1Login}/><Stack.Screen name="P1OTP" component={P1OTP}/><Stack.Screen name="P1Reset" component={P1Reset}/>
  <Stack.Screen name="P1Language" component={P1Language}/><Stack.Screen name="P1Terms" component={P1Terms}/><Stack.Screen name="P1HomeIntro" component={P1HomeIntro}/>
  <Stack.Screen name="P2Create" component={P2Create}/><Stack.Screen name="P2IdCheck" component={P2IdCheck}/><Stack.Screen name="P2Success" component={P2Success}/><Stack.Screen name="P2Admin" component={P2Admin}/>
  <Stack.Screen name="P2Join" component={P2Join}/><Stack.Screen name="P2Login" component={P2Login}/><Stack.Screen name="P2Verify" component={P2Verify}/><Stack.Screen name="P2Welcome" component={P2Welcome}/>
  <Stack.Screen name="P3Dashboard" component={P3Dashboard}/><Stack.Screen name="P3Teachers" component={P3Teachers}/><Stack.Screen name="P3Students" component={P3Students}/><Stack.Screen name="P3Parents" component={P3Parents}/><Stack.Screen name="P3Classes" component={P3Classes}/><Stack.Screen name="P3Subjects" component={P3Subjects}/><Stack.Screen name="P3Routine" component={P3Routine}/><Stack.Screen name="P3Attendance" component={P3Attendance}/><Stack.Screen name="P3Exams" component={P3Exams}/><Stack.Screen name="P3Notices" component={P3Notices}/>
 </Stack.Navigator></NavigationContainer>
}
export default App;
